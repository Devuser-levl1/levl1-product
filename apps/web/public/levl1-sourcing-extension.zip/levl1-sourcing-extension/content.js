"use strict";
(() => {
  // src/scrape.ts
  function scrapeProfile() {
    const text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
    const firstText = (sels) => {
      for (const s of sels) {
        const t = text(document.querySelector(s));
        if (t) return t;
      }
      return "";
    };
    const meta = (name) => {
      const el = document.querySelector(`meta[property="${name}"], meta[name="${name}"]`);
      return (el?.getAttribute("content") ?? "").trim();
    };
    const isLinkedIn = location.hostname.endsWith("linkedin.com") && location.pathname.startsWith("/in/");
    const isIndeed = location.hostname.endsWith("indeed.com");
    const isNaukri = location.hostname.endsWith("naukri.com");
    const result = {
      name: "",
      title: "",
      company: "",
      location: "",
      profileUrl: location.href.split("?")[0],
      email: "",
      phone: "",
      source: isLinkedIn ? "linkedin" : isIndeed ? "indeed" : isNaukri ? "naukri" : "generic"
    };
    try {
      const blocks = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
      for (const b of blocks) {
        const json = JSON.parse(b.textContent || "{}");
        const nodes = Array.isArray(json) ? json : json["@graph"] ?? [json];
        for (const n of nodes) {
          if (n && (n["@type"] === "Person" || Array.isArray(n["@type"]) && n["@type"].includes("Person"))) {
            if (!result.name && n.name) result.name = String(n.name);
            if (!result.title && n.jobTitle) result.title = String(n.jobTitle);
            if (!result.company && n.worksFor?.name) result.company = String(n.worksFor.name);
            if (!result.location && (n.address?.addressLocality || n.homeLocation?.name)) result.location = String(n.address?.addressLocality || n.homeLocation?.name);
          }
        }
      }
    } catch {
    }
    if (isLinkedIn) {
      if (!result.name) result.name = firstText(["h1.text-heading-xlarge", "main h1", "h1"]);
      if (!result.title) result.title = firstText([".text-body-medium.break-words", "div.text-body-medium"]);
      if (!result.location) result.location = firstText([".text-body-small.inline.t-black--light", "span.text-body-small.inline"]);
      if (!result.company) {
        const exp = document.querySelector('[aria-label*="Current company"], button[aria-label*="company"]');
        result.company = text(exp);
      }
    }
    if (isIndeed) {
      if (!result.name) result.name = firstText(['[data-testid="resume-name"]', 'h1[itemprop="name"]', "header h1", "main h1", "h1"]);
      if (!result.title) result.title = firstText(['[data-testid="resume-headline"]', '[itemprop="jobTitle"]', "h2.rezemp-ResumeDisplay-header"]);
      if (!result.company) result.company = firstText(['[data-testid="work-experience"] [data-testid="company"]', '[itemprop="worksFor"]']);
      if (!result.location) result.location = firstText(['[data-testid="resume-location"]', '[itemprop="address"]']);
    }
    if (isNaukri) {
      if (!result.name) result.name = firstText([".cand-name", '[data-ngp="candidateName"]', ".name", "header h1", "main h1", "h1"]);
      if (!result.title) result.title = firstText([".desig", ".designation", '[data-ngp="designation"]']);
      if (!result.company) result.company = firstText([".org", ".company", '[data-ngp="organization"]']);
      if (!result.location) result.location = firstText([".loc", ".location", '[data-ngp="location"]']);
    }
    if (!result.name) result.name = meta("og:title") || (document.title || "").split(/[|\-–]/)[0].trim();
    if (!result.title) result.title = meta("og:description") || meta("description");
    const mailto = document.querySelector('a[href^="mailto:"]');
    if (mailto) result.email = (mailto.getAttribute("href") || "").replace("mailto:", "").split("?")[0].trim();
    const tel = document.querySelector('a[href^="tel:"]');
    if (tel) result.phone = (tel.getAttribute("href") || "").replace("tel:", "").trim();
    const visible = document.body?.innerText || "";
    if (!result.email) {
      const m = visible.match(/[\w.+-]+@[\w-]+\.[\w.-]+/);
      if (m) result.email = m[0];
    }
    if (!result.phone) {
      const m = visible.match(/(\+?\d[\d\s().-]{8,}\d)/);
      if (m) result.phone = m[1].trim();
    }
    return result;
  }

  // src/content.ts
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "LEVL1_SCRAPE") {
      try {
        sendResponse({ ok: true, data: scrapeProfile() });
      } catch (e) {
        sendResponse({ ok: false, error: e instanceof Error ? e.message : "scrape failed" });
      }
    }
    return true;
  });
})();
