// src/types.ts
var DEFAULT_BASE_URL = "https://levl1.io";

// src/background.ts
chrome.runtime.onInstalled.addListener(async (details) => {
  const out = await chrome.storage.local.get("levl1_settings");
  if (!out.levl1_settings) {
    await chrome.storage.local.set({ levl1_settings: { apiKey: "", baseUrl: DEFAULT_BASE_URL, defaultJobId: "" } });
  }
  if (details.reason === "install") {
    chrome.runtime.openOptionsPage();
  }
});
